﻿namespace $safeprojectname$.Theming
{
    internal enum Theme
    {
        Light = 0,
        Dark = 1
    }
}
